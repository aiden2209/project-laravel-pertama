<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo e($title); ?></title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keyword" content="pulsa murah, pulsa murah, telkomsel murah, indosat murah,  murah banget, shoope, lazada, agen pulsa, ppob, murah," /><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous" />
    <link rel="shortcut icon" href="https://gamesaiden.000webhostapp.com/img/icon.png">
    <script async src="//jsfiddle.net/denisprasetio22/qpomb8v4/embed/"></script>
<link rel="stylesheet" href="https://gamesaiden.000webhostapp.com/css/arunika.css">

<link rel="stylesheet" href="https://gamesaiden.000webhostapp.com/css/anniversary.css" />
<!-- My CSS -->
<link rel="stylesheet" href="https://gamesaiden.000webhostapp.com/css/style.css" />

<link rel="stylesheet" href="https://gamesaiden.000webhostapp.com/css/table.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
  </head>
  <body>
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH D:\web\my-laravel\resources\views/layout/main.blade.php ENDPATH**/ ?>