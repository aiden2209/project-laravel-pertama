<!DOCTYPE html>
<html lang="en">
  <head>
    <title>DELINA PAYTRUZ | Agen PPOB Prabayara Termurah</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keyword" content="pulsa murah, pulsa murah, telkomsel murah, indosat murah,  murah banget, shoope, lazada, agen pulsa, ppob, murah," /><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous" />
    <link rel="shortcut icon" href="img/icon.png">
    <script async src="//jsfiddle.net/denisprasetio22/qpomb8v4/embed/"></script>
<link rel="stylesheet" href="https://www.niagahoster.co.id/assets/css/homepage-arunika.css?v=1.9.2">

<link rel="stylesheet" href="https://www.niagahoster.co.id/assets/css/anniversary.css?v=1.0.9" />
<!-- My CSS -->
<link rel="stylesheet" href="https://gamesaiden.000webhostapp.com/css/style.css" />



  </head>
  <body>
    <section class="h-100 w-100 bg-white" style="box-sizing: border-box">
      <div class="container-xxl mx-auto p-0 position-relative header-2-2" style="font-family: 'Poppins', sans-serif">
        <nav class="navbar navbar-expand-lg navbar-light">
          <a href="">
            <img style="margin-right: 0.75rem" src="https://gamesaiden.000webhostapp.com/img/logo.png" width="180px" alt="pulsa murah" />
          </a>
          <button class="navbar-toggler border-0" type="button" data-bs-toggle="modal" data-bs-target="#targetModal-item">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="modal-item modal fade" id="targetModal-item" tabindex="-1" role="dialog" aria-labelledby="targetModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content bg-white border-0">
                <div class="modal-header border-0" style="padding: 2rem; padding-bottom: 0">
                  <a class="modal-title" id="targetModalLabel">
                    <img style="margin-top: 0.5rem" src="https://gamesaiden.000webhostapp.com/img/logo.png" width="150px" alt="" />
                  </a>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 2rem; padding-top: 0; padding-bottom: 0">
                  <ul class="navbar-nav responsive me-auto mt-2 mt-lg-0">
                      <!-- ke1 -->
                      
                    <li class="nav-item">
                        <div class="dropdown as-dropdown-menu">
                        <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                        Layanan</div>
                        <div class="as-navbar__dropdown-container">
                        <div class="as-navbar__dropdown-content">
                        <a href="https://www.niagahoster.co.id/hosting-indonesia"  class="as-navbar__dropdown-link">
                        <div class="as-navbar__container">
                        <img src="https://gamesaiden.000webhostapp.com/img/Pulsa.png" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu" />
                        <div class="as-navbar__content">
                        <p class="as-navbar__title">Pulsa Seluler</p>
                        <p class="as-navbar__description">Tersedia Pulsa All Operator & Termurah</p>
                        </div>
                        </div>
                        </a>
                        <a href="https://www.niagahoster.co.id/cloud-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_CloudHost_Clicked')" class="as-navbar__dropdown-link">
                        <div class="as-navbar__container">
                        <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/cloud-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu cloud vps hosting" />
                        <div class="as-navbar__content">
                        <p class="as-navbar__title">Game</p>
                        <p class="as-navbar__description">Tersedia Item Game Termurah & 100% Aman</p>
                        </div>
                        </div>
                        </a>
                        <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                        <div class="as-navbar__container">
                        <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                        <div class="as-navbar__content">
                        <p class="as-navbar__title">Voucher Game</p>
                        <p class="as-navbar__description">Voucher Google Play Untuk Belanja Buku & Voucher Lainnya</p>
                        </div>
                        </div>
                        </a>
                        <a href="https://www.niagahoster.co.id/managed-wordpress" onclick="trackingClickCTA('CTA Click', 'Homepage_ManagedWordPress_Clicked')" class="as-navbar__dropdown-link">
                        <div class="as-navbar__container">
                        <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/managed-wordpress.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu managed wordpress" />
                        <div class="as-navbar__content">
                        <p class="as-navbar__title">Aplikasi Premium</p>
                        <p class="as-navbar__description">Dapatkan Aplikasi Premium Favorit Anda</p>
                        </div>
                        </div>
                        </a>
                        </div>
                        </div>
                        </div>
                        </li>
                        <!-- Harga -->
                        <li class="nav-item">
                            <div class="dropdown as-dropdown-menu">
                            <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                            Harga</div>
                            <div class="as-navbar__dropdown-container">
                            <div class="as-navbar__dropdown-content">
                            <a href="https://www.niagahoster.co.id/hosting-indonesia"  class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/unlimited-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Telkomsel</p>
                            <button class="btn btn-succes">ftgh</button>
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/cloud-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_CloudHost_Clicked')" class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/cloud-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu cloud vps hosting" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Indosat</p>
                            
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">XL</p>
                            
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Axis</p>
                            
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Smartfren</p>
                            
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/wordpress-hosting"  class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Mobile Legends</p>
                            
                            </div>
                            </div>
                            </a>
                            <a href="https://www.niagahoster.co.id/managed-wordpress" onclick="trackingClickCTA('CTA Click', 'Homepage_ManagedWordPress_Clicked')" class="as-navbar__dropdown-link">
                            <div class="as-navbar__container">
                            <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/managed-wordpress.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu managed wordpress" />
                            <div class="as-navbar__content">
                            <p class="as-navbar__title">Lihat Semuanya</p>
                           
                            </div>
                            </div>
                            </a>
                    
                   
                    <li class="nav-item">
                      <a class="nav-link" href="/about">About Us</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Contact</a>
                    </li>
                  </ul>
                </div>
                <div class="modal-footer border-0 gap-3" style="padding: 2rem; padding-top: 0.75rem">
                  <button class="btn btn-default btn-no-fill">Log In</button>
                  <button class="btn btn-fill text-white">Try Now</button>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Ke 2 -->
          <div class="collapse navbar-collapse" id="navbarTogglerDemo">
            <ul class="navbar-nav me-auto mt-2 mt-lg-0">
             
              <li class="nav-item">
                <div class="dropdown as-dropdown-menu">
                <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                Layanan</div>
                <div class="as-navbar__dropdown-container">
                <div class="as-navbar__dropdown-content">
                <a href="https://www.niagahoster.co.id/hosting-indonesia"  class="as-navbar__dropdown-link">
                <div class="as-navbar__container">
                <img src="https://gamesaiden.000webhostapp.com/img/Pulsa.png" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu" />
                <div class="as-navbar__content">
                <p class="as-navbar__title">Pulsa Seluler</p>
                <p class="as-navbar__description">Tersedia Pulsa All Operator & Termurah</p>
                </div>
                </div>
                </a>
                <a href="https://www.niagahoster.co.id/cloud-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_CloudHost_Clicked')" class="as-navbar__dropdown-link">
                <div class="as-navbar__container">
                <img src="https://gamesaiden.000webhostapp.com/img/Game.png" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu cloud vps hosting" />
                <div class="as-navbar__content">
                <p class="as-navbar__title">Game</p>
                <p class="as-navbar__description">Tersedia Item Game Termurah & 100% Aman</p>
                </div>
                </div>
                </a>
                <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                <div class="as-navbar__container">
                <img src="https://gamesaiden.000webhostapp.com/img/giftcard.png" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                <div class="as-navbar__content">
                <p class="as-navbar__title">Voucher Game</p>
                <p class="as-navbar__description">Voucher Google Play Untuk Belanja Buku & Voucher Lainnya</p>
                </div>
                </div>
                </a>
                <a href="https://www.niagahoster.co.id/managed-wordpress" onclick="trackingClickCTA('CTA Click', 'Homepage_ManagedWordPress_Clicked')" class="as-navbar__dropdown-link">
                <div class="as-navbar__container">
                <img src="https://gamesaiden.000webhostapp.com/img/netflix.png" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu managed wordpress" />
                <div class="as-navbar__content">
                <p class="as-navbar__title">Aplikasi Premium</p>
                <p class="as-navbar__description">Dapatkan Aplikasi Premium Favorit Anda</p>
                </div>
                </div>
                </a>
                </div>
                </div>
                </div>
                </li>
              
                <!-- Harga -->
                <li class="nav-item">
                    <div class="dropdown as-dropdown-menu">
                    <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                    Harga</div>
                    <div class="as-navbar__dropdown-container">
                    <div class="as-navbar__dropdown-content">
                    <a href="https://www.niagahoster.co.id/hosting-indonesia"  class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/unlimited-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Telkomsel</p>
                    <button class="btn btn-succes"></button>
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/cloud-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_CloudHost_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/cloud-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu cloud vps hosting" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Indosat</p>
                    
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">XL</p>
                    
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Axis</p>
                    
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Smartfren</p>
                    
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/wordpress-hosting" onclick="trackingClickCTA('CTA Click', 'Homepage_WordpressHost_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/wordpress-hosting.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu wordpress hosting" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Mobile Legends</p>
                    
                    </div>
                    </div>
                    </a>
                    <a href="https://www.niagahoster.co.id/managed-wordpress" onclick="trackingClickCTA('CTA Click', 'Homepage_ManagedWordPress_Clicked')" class="as-navbar__dropdown-link">
                    <div class="as-navbar__container">
                    <img src="https://www.niagahoster.co.id/assets/images/2021/arunika/navbar/managed-wordpress.svg" class="as-navbar__icon img-fluid" height="50" width="50" loading="lazy" alt="icon menu managed wordpress" />
                    <div class="as-navbar__content">
                    <p class="as-navbar__title">Lihat Semuanya</p>
                   
                    </div>
                    </div>
                    </a>
                    </div>
                    </div>
                    </div>
                    </li>
                    <a href="/about">
                    <li class="nav-item">
                        <div class="dropdown as-dropdown-menu">
                        <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                        About</div> </a> 
                    </div>
                    </li>  
                    <a href="/faq">
                    <li class="nav-item">
                        <div class="dropdown as-dropdown-menu">
                        <div class="as-navbar__dropdown-button" style="margin-top: 10px; margin-left: px;">
                        FAQ</div> </a> 
                    </div>
                    </li>  
                        
            </ul>
            <div class="gap-3">
              <button class="btn btn-default btn-no-fill">Log In</button>
              <button class="btn btn-fill text-white">Register</button>
            </div>
          </div>
        </nav>

        <div>
          
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH D:\web\my-laravel\resources\views/main.blade.php ENDPATH**/ ?>