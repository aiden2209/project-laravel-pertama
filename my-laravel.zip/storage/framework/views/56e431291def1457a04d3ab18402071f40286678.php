
<?php $__env->startSection('navbarku'); ?>
    

          <div class="mx-auto d-flex flex-lg-row flex-column hero">
            <!-- Left Column -->
            <div class="left-column d-flex flex-lg-grow-1 flex-column align-items-lg-start text-lg-start align-items-center text-center">
              <h2 class="title-text-big" style="font-size: 30px; margin-left: -30px;">
                SELAMAT DATANG DI DELIANA 
              </h2>
              <h2 class="title-text-big" style="font-size: 30px; margin-left: -30px; margin-top: -20px;">
                PAYTRUZ
              </h2>
              <p class="title-font" style="margin-left: -30px;">
               Nikmati Diskon menarik hingga 75% dengan Minimal Pembayaran Rp. 500.000,   
              </p>
              <p class="title-font" style="margin-left: -30px;">
                berlakuu untuk semua kategori yang tersedia. 
              </p>
              
            
              <br>
              <div class="d-flex flex-sm-row flex-column align-items-center mx-lg-0 mx-auto justify-content-center gap-3">
                <button class="btn d-inline-flex mb-md-0 btn-try text-white">Try it free</button>
                <button class="btn btn-outline">
                  <div class="d-flex align-items-center">
                    <svg class="me-2" width="13" height="12" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M10.9293 7.99988L6.66668 5.15788V10.8419L10.9293 7.99988ZM12.9173 8.27722L5.85134 12.9879C5.80115 13.0213 5.74283 13.0404 5.6826 13.0433C5.62238 13.0462 5.5625 13.0327 5.50934 13.0042C5.45619 12.9758 5.41175 12.9334 5.38075 12.8817C5.34976 12.83 5.33337 12.7708 5.33334 12.7105V3.28922C5.33337 3.22892 5.34976 3.16976 5.38075 3.11804C5.41175 3.06633 5.45619 3.02398 5.50934 2.99552C5.5625 2.96706 5.62238 2.95355 5.6826 2.95644C5.74283 2.95932 5.80115 2.97848 5.85134 3.01188L12.9173 7.72255C12.963 7.75299 13.0004 7.79423 13.0263 7.84261C13.0522 7.89099 13.0658 7.94501 13.0658 7.99988C13.0658 8.05475 13.0522 8.10878 13.0263 8.15716C13.0004 8.20553 12.963 8.24678 12.9173 8.27722Z"
                        fill="#555B61"
                      />
                    </svg>
                    Watch the video
                  </div>
                </button>
              </div>
            </div>
            <!-- Right Column -->
            <div class="right-column text-center d-flex justify-content-center pe-0">
              <img id="img-fluid" class="h-auto mw-100" src="http://api.elements.buildwithangga.com/storage/files/2/assets/Header/Header2/Header-2-1.png" alt="" />
            </div>
          </div>
      </div>
    </section>
    <section class="h-100 w-100" style="box-sizing: border-box; background-color: #141432">
      <div class="content-2-3 container-xxl mx-auto p-0 position-relative" style="font-family: 'Poppins', sans-serif">
        <div class="text-center title-text">
          <h1 class="text-title text-white">Daftar Reseller</h1>
          <p class="text-caption" style="margin-left: 3rem; margin-right: 3rem">Jika anda sebagai reseller daftar disini untuk memperoleh harga lebih murah lagi</p>
        </div>

        <div class="grid-padding text-center">
          <div class="row">
            <div class="col-lg-4 column">
              <div class="icon">
                <img src="http://api.elements.buildwithangga.com/storage/files/2/assets/Content/Content2/Content-2-8.png" alt="" />
              </div>
              <h3 class="icon-title text-white">Harga Lebih Murah</h3>
              <p class="icon-caption">
                Perbandingan harga lebih murah dari harga non reseller.
              </p>
            </div>
            <div class="col-lg-4 column">
              <div class="icon">
                <img src="http://api.elements.buildwithangga.com/storage/files/2/assets/Content/Content2/Content-2-9.png" alt="" />
              </div>
              <h3 class="icon-title text-white">Grup Private</h3>
              <p class="icon-caption">
                Jika join Reseller akan di invite ke grup private untuk menanyakan hal yang menurut anda sulut
              </p>
            </div>
            <div class="col-lg-4 column">
              <div class="icon">
                <img src="http://api.elements.buildwithangga.com/storage/files/2/assets/Content/Content2/Content-2-10.png" alt="" />
              </div>
              <h3 class="icon-title text-white">Hanya 150.000</h3>
              <p class="icon-caption">
                Hanya Rp. 150.000 anda sudah bisa mendapatkan keuntungan lebih besar nantiya
              </p>
            </div>
          </div>
        </div>

        <div class="card-block">
          <div class="card">
            <div class="d-flex flex-lg-row flex-column align-items-center">
              <div class="me-lg-3">
                <img src="http://api.elements.buildwithangga.com/storage/files/2/assets/Content/Content2/Content-2-1%20(1).png" alt="" />
              </div>
              <div class="flex-grow-1 text-lg-start text-center card-text">
                <h3 class="card-title text-white">Buruan Join Tunggu apa Lagi!</h3>
                <p class="card-caption">
                  Harga tersebut termasuk harga promo jadi harga bisa berubah sewaktu-waktu.
                </p>
              </div>
              <div class="card-btn-space">
                <button class="btn btn-card text-white">Join Sekarang</button>
                <button class="btn btn-outline">Versi Gratis</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\my-laravel\resources\views/home.blade.php ENDPATH**/ ?>