

<?php $__env->startSection('navbarku'); ?>
    <h1>ini faq</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\my-laravel\resources\views/faq.blade.php ENDPATH**/ ?>