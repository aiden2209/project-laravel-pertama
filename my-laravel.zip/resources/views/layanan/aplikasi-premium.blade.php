@extends('layout.main')
@section('navbarku')
    

   <h1>ini aplikasi premium</h1> 
   @endsection