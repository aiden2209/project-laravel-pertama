@extends('layout.main')
@section('navbarku')


<div class="col-md-12 col-sm-12 col-lg-8">
    <form name="wpu-contact-form">
    <div class="row">                 
    <div class="col-12 mb-3">
    <div class="card">
    <div class="card-body">
    <div class="text-white text-center position-absolute circle-primary"></div><h5 style="margin-bottom: -50px">Lengkapi data</h5>
    <hr><div class="form-row mt-4">
    <div class="col" style="margin-top: -50px; margin-bottom: -50px">
  <input type="number" class="form-control" name="UserID" placeholder="Masukan UserID" required>
      </div>
      <div class="col" style="margin-top: -50px">
          <input type="number" class="form-control" name="ZoneID" placeholder="Masukan ServerID" maxlength="5" required>
      </div>
  </div>
 <div class="mt-3">
     
 </div>
            </div>
        </div>
        
    </div>
             <div id="note"></div>
  <div class="col-12 mb-3">
  <div class="card">
          <div class="card-body">
          <div class="text-white text-center position-absolute circle-primary"></div>
          <h5 style="margin-bottom: -50px">Pilih nominal</h5>
              <hr><div class="mt-4">
                  <div class="panel-topup" style="margin-top:-50px ">
                      <input type="radio" id="nominal0" name="nominal" value="Diamonds 0">
        <label for="nominal0">86 Diamonds</label><input type="radio" id="nominal1" name="nominal" value="Diamonds 86">
        <label for="nominal1">172 Diamonds</label><input type="radio" id="nominal2" name="nominal" value="Diamonds 172">
        <label for="nominal2">257 Diamonds</label><input type="radio" id="nominal3" name="nominal" value="Diamonds 257">
        <label for="nominal3">344 Diamonds</label><input type="radio" id="nominal4" name="nominal" value="Diamonds 344">
        <label for="nominal4">429 Diamonds</label><input type="radio" id="nominal5" name="nominal" value="Diamonds 429">
        <label for="nominal5">514 Diamonds</label><input type="radio" id="nominal6" name="nominal" value="Diamonds 514">
        <label for="nominal6">706 Diamonds</label><input type="radio" id="nominal7" name="nominal" value="Diamonds 706">
        <label for="nominal7">878 Diamonds</label><input type="radio" id="nominal8" name="nominal" value="Diamonds 878">
        <label for="nominal8">963 Diamonds</label><input type="radio" id="nominal9" name="nominal" value="Diamonds 963">
        <label for="nominal9">1412 Diamonds</label><input type="radio" id="nominal10" name="nominal" value="Diamonds 1412">
        <label for="nominal10">2195 Diamonds</label><input type="radio" id="nominal11" name="nominal" value="Diamonds 2195">
        <label for="nominal11">3688 Diamonds</label><input type="radio" id="nominal12" name="nominal" value="Diamonds 3688">
        <label for="nominal12">5532 Diamonds</label><input type="radio" id="nominal13" name="nominal" value="Diamonds 5532">
        <label for="nominal13">9288 Diamonds</label><input type="radio" id="nominal14" name="nominal" value="Diamonds 9288">
        <label for="nominal14">Twilight Pass</label><input type="radio" id="nominal15" name="nominal" value="Twilight Pass">
        <label for="nominal15">Starlight Member</label><input type="radio" id="nominal16" name="nominal" value="Starlight Member">
        <label for="nominal16">Starlight Member Plus</label><input type="radio" id="nominal17" name="nominal" value="Starlight Member Plus">
        </div>
        </div>
        </div>
        </div>
        </div>
                            <div class="col-12 mb-3">
                            <div class="card">
     <div class="card-body">
    <div class="text-white text-center position-absolute circle-primary"></div>
     <h5 style="margin-bottom: -50px">Pilih metode pembayaran</h5>
           <hr><div class="mt-4">
           <div class="methods" style="margin-top: -50px">
           <input class="mtdbtn" type="radio" id="payment" name="payment" value="Payment Gateway">
           <label class="mtdlabel" for="payment"><img src="https://xcashshop.com/assets/images/1625996778.png" class="img-fluid">
        <p class="float-right">
       <span class="badge badge-success" id="QRIS"></span>
                   </p>
               </label>
          </div>
               </div>
               </div>
            </div>
           </div>
           <div class="col-12 mb-3">
               <div class="card">
  <div class="card-body">
  <div class="text-white text-center position-absolute circle-primary"></div>
  <h5 style="margin-bottom:-50px ">Masukan nomor whatsapp</h5>
      <hr><div class="mt-4">
          <input  style="margin-top: -50px" type="number" class="form-control" id="nowa" name="no" placeholder="08xxxxxxxxx"
              required>
                       </div>
     </div>
      </div>
   </div>
      <div class="col-12 mb-3">
   <!-- button 1 -->
    <button type="submit" class="btn btn-primary btn-kirim">Konfirmasi</button>
  <!-- button 2 -->
    <button class="btn btn-primary btn-loading d-none" type="button" disabled>
       <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
      Tunggu Bentar Yahhh.
                  </button>
                  
      </div> 
        </div>   
          </div>
      </form>
      <div class="my-alert alert-success d-none " role="alert" style="padding:10px ;border-radius:10px">
        <h4 class="alert-heading">Terimakasih!</h4>
        <br>
        <p  style="margin-bottom: 50px">Pesanan Anda Telah Kami Terima Harap Lakukan Pembayaran Sesuai dengan nominal transaksi yang sudah di tentukan! </p>
        <a href="">
        <button type="submit" class="btn btn-success">Lanjutkan</button></a>
      </div>
       </div>
       </div>
    
    </body>
    
    
         <script>
          const scriptURL = 'https://script.google.com/macros/s/AKfycbxlU57eFJz8BGu8BXa70Y6wUf6ghfyceVeunFKnEYZ2XuoM4x_XaGdc1Sxi1FRDN2QFjg/exec'
          const form = document.forms['wpu-contact-form'];
          const btnKirim = document.querySelector('.btn-kirim');
          const btnLoading = document.querySelector('.btn-loading');
          const myAlert = document.querySelector('.my-alert')
        
          form.addEventListener('submit', e => {
            e.preventDefault()
            // ketika tombol submit diklik
            // tampilkan tombol loading, hilangkan tombol kirim
            btnLoading.classList.toggle('d-none');
            btnKirim.classList.toggle('d-none');
            fetch(scriptURL, { method: 'POST', body: new FormData(form)})
              .then(response => {
                // tampilkan tombol kirim, hilangkan loading
                btnLoading.classList.toggle('d-none');
                btnKirim.classList.toggle('d-none');
                 // tampilkan alert
                 myAlert.classList.toggle('d-none');
                //  reset formnya
                form.reset();
                console.log('Success!', response);
               
              })
              .catch(error => console.error('Error!', error.message))
          })
        </script>

        <style>
        
/* ini strip */
.strip-primary {
  background-color: #0061fd;
  position: absolute;
  width: 40px;
  height: 5px;
  border-radius: 10px;
}
/* ini radio */
input[type="radio"] {
  color: white;
  display: none;
  margin: 20px;
  cursor: pointer;
}

input[type="radio"]:checked + label {
  text-align: center;
  background-image: none;
  background-color: #0061fd;
  color: white;
  cursor: pointer;
  border-radius: 5px;
  width: 49%;
  font-size: 14px;
}

input[type="radio"] + label {
  text-align: center;
  color: #292929;
  display: inline-block;
  padding: 5px;
  background-color: #fdfdfd;
  border-color: #0061fd;
  border: 2px solid #0061fd;
  cursor: pointer;
  border-radius: 5px;
  width: 49%;
  font-size: 14px;
}

/* ini style radio */
@media (min-width: 576px) {
  input[type="radio"]:checked + label {
    width: 210px;
    font-size: 14px;
    padding: 5px;
  }

  input[type="radio"] + label {
    width: 210px;
    font-size: 14px;
    padding: 5px;
  }
}

/* ini payment */
.mtdbtn:checked + .mtdlabel {
  text-align: left;
  background-color: #0066ff;
  -webkit-filter: grayscale(0%);
  /* Safari 6.0 - 9.0 */
  filter: grayscale(0%);
  cursor: pointer;
  padding: 14px;
  border: 0px;
}
    </style>

 
   @endsection