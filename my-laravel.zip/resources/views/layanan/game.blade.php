@extends('layout.main')
@section('navbarku')
    

   <h1>ini game</h1> 
   @endsection