@extends('layout.main')
@section('navbarku')
    

   <h1>Ini voucher game</h1> 
   @endsection