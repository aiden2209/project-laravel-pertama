@extends('layout.main')

@section('navbarku')
    <h1>ini faq</h1>
@endsection