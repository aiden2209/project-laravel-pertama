@extends('layout.main')
@section('navbarku')
    

   <h1>Ini about</h1> 
   @endsection