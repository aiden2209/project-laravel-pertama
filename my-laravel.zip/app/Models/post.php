<?php

namespace App\Models;

class post 
{
   
}
